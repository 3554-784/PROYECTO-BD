--Promedio del Indice de Calidad del Aire por estación

SELECT s."StationName" AS estacion,
	AVG(d."AQI") AS promedio_aqi
FROM station_day d
JOIN stations s ON d."StationId" = s."StationId"
GROUP BY s."StationName"
ORDER BY promedio_aqi DESC
LIMIT 5;